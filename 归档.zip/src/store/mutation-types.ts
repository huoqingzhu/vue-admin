export const ACCESS_TOKEN = 'Access-Token' // 用户token
export const CURRENT_USER = 'Current-User' // 当前用户信息
export const IS_LOCKSCREEN = 'Is-Lockscreen' // 是否锁屏
export const TABS_ROUTES = 'Tabs-Routes' // 标签页


